# MERN Jobify

A **MERN stack job tracking** application that allows users to manage job applications efficiently. Users can register, log in, track job applications, and update their status.
