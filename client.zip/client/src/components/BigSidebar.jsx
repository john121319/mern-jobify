import Wrapper from "../assets/wrappers/BigSidebar"

const BigSidebar = () => {
  return (
    <Wrapper>BigSidebar</Wrapper>
  )
}

export default BigSidebar