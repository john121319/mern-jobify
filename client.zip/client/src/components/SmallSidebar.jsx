import Wrapper from "../assets/wrappers/SmallSidebar"

const SmallSidebar = () => {
  return (
    <Wrapper>SmallSidebar</Wrapper>
  )
}

export default SmallSidebar