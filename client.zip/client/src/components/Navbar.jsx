import Wrapper from "../assets/wrappers/Navbar"
const Navbar = () => {
  return (
    <Wrapper>Navbar</Wrapper>
  )
}

export default Navbar