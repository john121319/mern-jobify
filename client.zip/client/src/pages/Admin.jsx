import React from 'react'

const Admin = () => {
  return <h1>Admin Page</h1>
}

export default Admin
