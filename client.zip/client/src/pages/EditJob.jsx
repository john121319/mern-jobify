import React from 'react'

const EditJob = () => {
  return <h1>Edit Job</h1>
}

export default EditJob
