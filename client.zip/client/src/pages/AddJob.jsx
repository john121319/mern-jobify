import React from 'react'

const AddJob = () => {
  return <h1>Add job</h1>
}

export default AddJob
