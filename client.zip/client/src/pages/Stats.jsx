import React from 'react'

const Stats = () => {
  return <h1>stats</h1>
}

export default Stats
