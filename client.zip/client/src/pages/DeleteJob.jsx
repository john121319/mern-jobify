import React from 'react'

const DeleteJob = () => {
  return <h1>delete job</h1>
}

export default DeleteJob
